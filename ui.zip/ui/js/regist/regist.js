/**
 * @author:jimi 注册表单的校验，采用bootstrapvalidator
 */
$(function(){

    $("#registForm").bootstrapValidator({
        //enabled:内容有变化就验证；disabled：submitted提交时验证
        live:'disenabled',
        //排除无需验证的控件，比如被禁用的或者被隐藏的
        excluded: [':disabled', ':hidden', ':not(:visible)'],
        //提交按钮，如果表单验证失败则该按钮会变成disabled不会触发
        submitButtons: '#submitRegist',
        message: '通用的验证失败消息',
        //根据验证结果显示的各种图标
        /**feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },**/

        fields: {
            // 用户名校验
            username: {
                validators: {
                    notEmpty: {//检测非空,radio也可用
                        message: '用户名不能为空'
                         },
                    stringLength: {
                        min: 1,
                        max: 20,
                        message: '用户名不能超过20个字符'
                    },
                    }
                },
            // 密码
            password: {
                validators: {
                    notEmpty: {//检测非空,radio也可用
                        message: '密码不能为空'
                    },
                    different: {//不能和用户名相同
                        field: 'username',//需要进行比较的input name值
                        message: '不能和用户名相同'
                    },
                    identical: {//相同
                        field: 'password_again',
                        message: '两次密码不一致'
                    }
                }
            },
            password_again: {
                validators: {
                    notEmpty: {//检测非空
                        message: '确认密码不能为空'
                    },
                    different: {//不能和用户名相同
                        field: 'username',//需要进行比较的input name值
                        message: '不能和用户名相同'
                    },
                    identical: {//相同
                        field: 'password',
                        message: '两次密码不一致'
                    }
                }
            },
            mobile: {
                validators: {
                    notEmpty: {//检测非空
                        message: '手机号码不能为空'
                    },
                    stringLength: {
                        min: 11,
                        max: 11,
                        message: '请输入11位手机号码'
                    },
                    regexp: {
                        regexp: /^1[3|5|8]{1}[0-9]{9}$/,
                        message: '请输入正确的手机号码'
                    }
                }
            },
            code: {
                validators: {
                    notEmpty: {//检测非空
                        message: '验证码不能为空'
                    },
                    stringLength: {
                        min: 4,
                        max: 4,
                        message: '验证码为4位数'
                    },
                    regexp: {
                        regexp: /^[0-9]*$/,
                        message: '验证码只能是数字'
                    }
                }
            }

            }
    });



});






/**
 * 表单校验格式，以下以一个属性为例子
 * username: {
                validators: {
                    notEmpty: {//检测非空,radio也可用
                        message: '用户名不能为空'
                         }//,
                        stringLength: {//检测长度
                             min: 3,
                             max: 30,
                             message: '长度必须在3-30之间'
                         },
                         regexp: {//正则验证
                             regexp: /^[a-zA-Z0-9_\.]+$/,
                             message: '所输入的字符不符要求'
                         },
                         remote: {//将内容发送至指定页面验证，返回验证结果，比如查询用户名是否存在
                             url: '指定页面',
                             message: 'The username is not available'
                         },
                         different: {//与指定文本框比较内容相同
                             field: '指定文本框name',
                             message: '不能与指定文本框内容相同'
                         },
                         emailAddress: {//验证email地址
                             message: '不是正确的email地址'
                         },
                         identical: {//与指定控件内容比较是否相同，比如两次密码不一致
                             field: 'confirmPassword',//指定控件name
                             message: '输入的内容不一致'
                         },
                         date: {//验证指定的日期格式
                             format: 'YYYY/MM/DD',
                             message: '日期格式不正确'
                         },
                         choice: {//check控件选择的数量
                             min: 2,
                             max: 4,
                             message: '必须选择2-4个选项'
                         }
                    }
                }
 *
 *
 *
 * **/